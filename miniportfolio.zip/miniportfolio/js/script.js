document.addEventListener('DOMContentLoaded', function() {
    // Function to load page content
    function loadPage(page) {
        fetch(page)
        .then(response => response.text())
        .then(data => {
            document.getElementById('content').innerHTML = data;
        })
        .catch(err => console.log('Error loading page:', err));
    }

    // Attach event listeners for the nav links
    document.getElementById('home-link').addEventListener('click', function(event) {
        event.preventDefault();
        loadPage('home.html');
    });

    document.getElementById('about-link').addEventListener('click', function(event) {
        event.preventDefault();
        loadPage('about.html');
    });

    document.getElementById('projects-link').addEventListener('click', function(event) {
        event.preventDefault();
        loadPage('projects.html');
    });

    document.getElementById('skills-link').addEventListener('click', function(event) {
        event.preventDefault();
        loadPage('skills.html');
    });

    document.getElementById('contact-link').addEventListener('click', function(event) {
        event.preventDefault();
        loadPage('contact.html');
    });

    // Load home page content by default
    loadPage('home.html');

    // Redirect link on the home page to About Me page
    document.addEventListener('click', function(event) {
        if (event.target && event.target.id === 'about-redirect') {
            event.preventDefault();
            loadPage('about.html');
        }
    });
});
